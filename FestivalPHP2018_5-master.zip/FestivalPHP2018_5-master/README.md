Projet Festival (Festival Folklores du Monde de Saint Malo) en Php pour le module de PPE 2SLAM à La Joliverie
Version initiale étudiants : à cloner
