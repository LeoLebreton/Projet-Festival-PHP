
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","modele\\dao\\AttributionDAO"],["c","modele\\dao\\Bdd"],["c","modele\\dao\\EtablissementDAO"],["c","modele\\dao\\GroupeDAO"],["c","modele\\dao\\OffreDAO"],["c","modele\\dao\\TypeChambreDAO"],["c","modele\\dao\\UtilisateurDAO"],["c","PDO"],["c","PDOStatement"],["c","Traversable"]];
