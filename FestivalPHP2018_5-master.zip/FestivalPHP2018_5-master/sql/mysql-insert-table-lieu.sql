/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  btssio
 * Created: 17 oct. 2018
 */

insert into Lieu values ('0500L', 'Le Lac', '20 rue du sapin', '35407', 'Saint-Malo', 500);
insert into Lieu values ('0450L', 'La Poule', '33 rue du vin', '35404', 'Paramé', 450);
insert into Lieu values ('0268L', 'Le Canard', '2 rue du chiffre', '35407', 'Saint-Malo', 200);
