/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  btssio
 * Created: 7 nov. 2018
 */

INSERT INTO `Representation` (`id`, `idGroupe`, `idLieu`, `date`, `heureDebut`, `heureFin`) VALUES ('0100R', 'g005', '0500L', '2018-11-07', '15:30:00', '17:00:00');
INSERT INTO `Representation` (`id`, `idGroupe`, `idLieu`, `date`, `heureDebut`, `heureFin`) VALUES ('0120R', 'g006', '0450L', '2018-11-02', '16:00:00', '17:00:00');
INSERT INTO `Representation` (`id`, `idGroupe`, `idLieu`, `date`, `heureDebut`, `heureFin`) VALUES ('0140R', 'g004', '0500L', '2018-11-07', '17:00:00', '18:00:00');
